package Ex3;

import java.util.*;

public class Agenda {
    private List<Pessoa> pessoas;
    
    public List<Pessoa> getPessoas() {
        return pessoas;
    }

    public Agenda(){
        this.pessoas = new ArrayList<Pessoa>();
    }

    public void armazenaPessoa(String nome, int idade, float altura){
        pessoas.add(new Pessoa(nome, idade, altura));
    }

    public void removePessoa(String nome){
        for (Pessoa p : pessoas){
            if (p.getNome().equals(nome)){
                pessoas.remove(p);
                break;
            }
        }
    }

    public int buscaPessoa(String nome){
        for(Pessoa p : pessoas){
            if (p.getNome().equals(nome)){
                return pessoas.lastIndexOf(p);
            }
        }
        return -1;
    }

    public void imprimeAgenda(){
        for (Pessoa p : pessoas)
            System.out.println(p.printPessoa());
    }

    public void imprimePessoa(int index){
        if (index >= pessoas.size())
            System.out.println("Erro: index ultrapassou o tamanho da agenda");
        else
            System.out.println("Pessoa com o id = "+index+" --> "+pessoas.get(index).printPessoa());
    }
}
