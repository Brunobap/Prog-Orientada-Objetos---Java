package Ex3;

public class Main {
    public static void main(String[] args) {
        Agenda agenda = new Agenda();
        agenda.armazenaPessoa("Alberto", 40, 2.0f);
        agenda.armazenaPessoa("Bruno", 20, 1.72f);
        agenda.armazenaPessoa("Carlos", 13, 1.45f);
        agenda.armazenaPessoa("Drauzio", 78, 1.69f);
        agenda.imprimeAgenda();        
        System.out.println("");

        agenda.removePessoa("Bruno");
        agenda.imprimeAgenda(); 
        
        System.out.println("\nId de Carlos: "+agenda.buscaPessoa("Carlos"));
        System.out.println("");

        agenda.imprimePessoa(2);
        System.out.println("");
    }
}
