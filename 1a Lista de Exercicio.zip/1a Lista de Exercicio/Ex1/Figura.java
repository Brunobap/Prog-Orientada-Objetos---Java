package Ex1;

public abstract class Figura{
    private String cor;
    public String getCor() {
        return cor;
    }
    public void setCor(String cor) {
        this.cor = cor;
    }

    public abstract double area();

    public String toString(){
        return ", e área = "+this.area();
    }
}