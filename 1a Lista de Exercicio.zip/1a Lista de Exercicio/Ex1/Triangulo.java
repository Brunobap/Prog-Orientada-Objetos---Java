package Ex1;

public class Triangulo extends Figura {
    private double base, altura;

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public Triangulo(double base, double altura, String cor){
        this.base = base;
        this.altura = altura;
        this.setCor(cor);
    }

    @Override
    public String toString(){
        return "Um triângulo com base "+this.getBase()+" e altura "+this.getAltura()+super.toString();
    }

    @Override
    public double area(){
        return (this.getBase()*this.getBase())/2;
    }
}
