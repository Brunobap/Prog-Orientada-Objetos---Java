package Ex1;

public class Circulo extends Figura {
    private double raio;

    public double getRaio() {
        return raio;
    }
    public void setRaio(double raio) {
        this.raio = raio;
    }

    public Circulo(double raio, String cor){
        this.raio = raio;
        this.setCor(cor);
    }

    @Override
    public double area(){
        return 3.14 * this.getRaio() * this.getRaio();
    }

    public double getDiametro(){
        return this.getRaio()*2;
    }

    @Override
    public String toString(){
        return "Um círculo de raio "+this.getRaio()+super.toString();
    }
}
