package Ex1;

public class Quadrado extends Retangulo {

    public Quadrado(double lado, String cor) {
        super(lado, lado, cor);
    }
    
    @Override
    public String toString(){
        return "Um quadrado de lados "+this.getLado1()+super.toString();
    }
}
