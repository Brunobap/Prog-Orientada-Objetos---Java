package Ex1;

public class Main {
    public static void main(String[] args) {
        Circulo circ = new Circulo(2,"Azul");
        System.out.println("Área de circ: "+circ.area());
        System.out.println(circ.toString());
        System.out.println("Diametro de circ: "+circ.getDiametro());
        System.out.println("Cor de circ:"+circ.getCor());
        
        Retangulo rect = new Retangulo(3,2,"Vermelho");
        System.out.println("\nÁrea de rect:"+rect.area());
        System.out.println(rect.toString());
        System.out.println("Cor de rect:"+rect.getCor());
        
        Triangulo trng = new Triangulo(3,2,"Verde");
        System.out.println("\nÁrea de trng:"+trng.area());
        System.out.println(trng.toString());
        System.out.println("Cor de trng:"+trng.getCor());
        
        Quadrado quad = new Quadrado(2,"Rosa");
        System.out.println("\nÁrea de quad:"+quad.area());
        System.out.println(quad.toString());
        System.out.println("Cor de quad:"+quad.getCor());
    }
}
