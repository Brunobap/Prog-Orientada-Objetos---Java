package Ex2;

public class Caminhao extends Veiculo {
    private int eixos;

    public int getEixos() {
        return eixos;
    }
    public void setEixos(int eixos) {
        this.eixos = eixos;
    }

    public Caminhao(String placa, int ano, int eixos){
        super(placa, ano);
        this.eixos = eixos;
    }

    @Override
    public void exibirDados(){
        System.out.println("Tipo: Caminhão - Placa: "+this.getPlaca()+" - Ano: "+this.getAno()+" - Eixos: "+this.getEixos());
    }
}
