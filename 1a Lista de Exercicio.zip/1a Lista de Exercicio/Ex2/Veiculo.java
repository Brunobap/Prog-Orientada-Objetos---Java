package Ex2;

public class Veiculo {
    private String placa;
    private int ano;

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public Veiculo(){
        this.ano = 0;
        this.placa = "";
    }
    public Veiculo(String placa, int ano){
        this.ano = ano;
        this.placa = placa;
    }

    public void exibirDados(){
        System.out.println("Placa: "+this.getPlaca()+" - Ano: "+this.getAno());
    }
}
