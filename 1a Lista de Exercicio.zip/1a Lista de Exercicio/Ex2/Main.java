package Ex2;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Veiculo> veiculos = new ArrayList<Veiculo>();
        veiculos.add(new Caminhao("cnweio",1982,3));
        veiculos.add(new Onibus("2903e",2001,30));
        veiculos.add(new Onibus("c3fni",1971,15));
        veiculos.add(new Onibus("gv3tb4",2020,42));
        veiculos.add(new Caminhao("0m92x3",2015,2));
        veiculos.add(new Caminhao("yb90jm",1999,1));

        for(Veiculo v : veiculos)
            v.exibirDados();
    }
}
