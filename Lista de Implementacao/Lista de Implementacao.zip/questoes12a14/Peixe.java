package questoes12a14;

public class Peixe extends Animal {

    @Override
    public void mover() {
        System.out.println("O peixe está nadando");
    }    
}
