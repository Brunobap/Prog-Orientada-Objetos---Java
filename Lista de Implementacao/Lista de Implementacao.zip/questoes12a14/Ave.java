package questoes12a14;

public class Ave extends Animal {

    @Override
    public void mover() {
        System.out.println("A ave está nadando");
    }    
}
