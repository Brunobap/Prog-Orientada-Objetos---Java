package questoes12a14;

public class Animal {
    public void mover() {
        System.out.println("O animal está se movendo");
    }
}
